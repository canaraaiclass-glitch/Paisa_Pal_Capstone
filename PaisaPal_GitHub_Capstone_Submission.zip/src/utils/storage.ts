import { AppRow, UserProfile, StorageResult } from '../types';
import { fmtD, toDay, todayIST, DAY, uid } from './calculations';
import { getInitialTrialAppRows } from '../data/dummyDocuments';

export const STORAGE_KEY = 'due-dates-alert-v1';
export const STORAGE_BACKUP_KEY = 'due-dates-alert-v1-prev-backup';

export interface StoredPayload {
  rows: AppRow[] | string; // Plaintext array or encrypted string ciphertext
  profile: UserProfile;
  encrypted?: boolean;
  vaultIv?: string;
  vaultSalt?: string;
  version?: number;
}
export const IRIN_JOSEPH_FD_ROWS: AppRow[] = [
  {
    id: 'fd-sbi-43203056352',
    kind: 'inv',
    data: {
      name: 'SBI Senior Citizen Term Deposit',
      type: 'fd',
      holder: 'Irin Joseph',
      institution: 'State Bank of India',
      ref: '43203056352',
      invested: 400000,
      current: 400000,
      rate: 7.1,
      start: '2025-10-18',
      maturity: '2027-01-05',
      hasAttachment: true,
      notes:
        'Scheme: TDR SR CT UNI-180-3653D-INR | CIF: 8902331911-7 | PAN: NOACSPI5507N | Term: 444 Days @ 7.10% | Monthly interest payout ₹2,352.80 | Nominee: Tony Joseph | Thodupuzha Matha Complex Branch, Kerala',
      attachmentUrl: '/assets/aistudio/Irin_FD_SBI_74546726.pdf',
      attachmentName: 'Irin_FD_SBI_74546726.pdf',
    },
  },
  {
    id: 'fd-kgb-40328202400250',
    kind: 'inv',
    data: {
      name: 'Kerala Gramin Bank KVD Senior FD',
      type: 'fd',
      holder: 'Irin Joseph',
      institution: 'Kerala Gramin Bank',
      ref: '40328202400250',
      invested: 56323,
      current: 63573,
      rate: 7.0,
      start: '2026-07-05',
      maturity: '2028-01-11',
      hasAttachment: true,
      notes:
        'Deposit Head: KVD SENIOR | Printed Sl. No: 2146479 | Cust ID: 410741929 | Term: 555 Days @ 7.00% compounded | Interest ₹7,250 | Maturity Value ₹63,573 | Nominee: Tony Joseph | Auto Renewal: YES | Thodupuzha Branch',
      attachmentUrl: '/assets/aistudio/Irin_FD_Gramin_Bank_5d23749c.pdf',
      attachmentName: 'Irin_FD_Gramin_Bank_5d23749c.pdf',
    },
  },
];

export function loadStoredData(): {
  rows: AppRow[];
  profile: UserProfile;
  isEncrypted?: boolean;
  encryptedRowsCiphertext?: string;
  vaultIv?: string;
} {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return {
        rows: generateSampleData(),
        profile: { whatsapp: '', showUpload: true, theme: 'system' },
      };
    }

    const parsed = JSON.parse(raw);

    // Deeply preserve the full profile including all security, recovery, emergency and nominee settings
    const loadedProfile: UserProfile = {
      whatsapp: parsed.profile?.whatsapp || '',
      showUpload: parsed.profile?.showUpload !== false,
      theme: parsed.profile?.theme || 'system',
      pinEnabled: Boolean(parsed.profile?.pinEnabled),
      pinHash: parsed.profile?.pinHash || undefined,
      pinSalt: parsed.profile?.pinSalt || undefined,
      biometricEnabled: Boolean(parsed.profile?.biometricEnabled),
      emergencyNotes: parsed.profile?.emergencyNotes || undefined,
      emergencyContacts: Array.isArray(parsed.profile?.emergencyContacts)
        ? parsed.profile.emergencyContacts
        : undefined,
      primaryBank: parsed.profile?.primaryBank || undefined,
      nomineeNotes: parsed.profile?.nomineeNotes || undefined,
      vaultEncrypted: Boolean(parsed.profile?.vaultEncrypted || parsed.encrypted),
      vaultSalt: parsed.profile?.vaultSalt || parsed.vaultSalt || undefined,
      vaultVerification: parsed.profile?.vaultVerification || undefined,
      vaultIv: parsed.profile?.vaultIv || parsed.vaultIv || undefined,
      recoveryKeyHash: parsed.profile?.recoveryKeyHash || undefined,
      recoveryKeySalt: parsed.profile?.recoveryKeySalt || undefined,
      lastBackupAt: parsed.profile?.lastBackupAt || undefined,
    };

    // Check if the payload is encrypted
    if (parsed.encrypted && typeof parsed.rows === 'string') {
      return {
        rows: [],
        profile: loadedProfile,
        isEncrypted: true,
        encryptedRowsCiphertext: parsed.rows,
        vaultIv: parsed.vaultIv,
      };
    }

    return {
      rows: Array.isArray(parsed.rows) ? parsed.rows : generateSampleData(),
      profile: loadedProfile,
      isEncrypted: false,
    };
  } catch (e: any) {
    console.error('Error loading data from localStorage', e);
    return {
      rows: generateSampleData(),
      profile: { whatsapp: '', showUpload: true, theme: 'system' },
      isEncrypted: false,
    };
  }
}

export function saveStoredData(
  rows: AppRow[] | string,
  profile: UserProfile,
  options?: { isEncrypted?: boolean; vaultIv?: string; vaultSalt?: string }
): StorageResult {
  try {
    // Keep a pre-write backup in case of storage failure or corruption
    const current = localStorage.getItem(STORAGE_KEY);
    if (current) {
      try {
        localStorage.setItem(STORAGE_BACKUP_KEY, current);
      } catch {
        // Non-critical if backup cannot be stored
      }
    }

    const payload: StoredPayload = {
      rows,
      profile,
      encrypted: options?.isEncrypted ?? profile.vaultEncrypted ?? false,
      vaultIv: options?.vaultIv ?? profile.vaultIv,
      vaultSalt: options?.vaultSalt ?? profile.vaultSalt,
      version: 2,
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    return { success: true };
  } catch (e: any) {
    console.error('Error persisting data to localStorage', e);
    const isQuota =
      e?.name === 'QuotaExceededError' ||
      e?.name === 'NS_ERROR_DOM_QUOTA_REACHED' ||
      e?.code === 22 ||
      e?.code === 1014;
    return {
      success: false,
      error: isQuota
        ? 'Storage quota exceeded. Please export backup and clear old scans.'
        : e?.message || 'Storage failure in browser storage.',
    };
  }
}

export function clearStoredData(): boolean {
  try {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STORAGE_BACKUP_KEY);
    return true;
  } catch (e) {
    console.error('Error clearing localStorage', e);
    return false;
  }
}

export function generateSampleData(): AppRow[] {
  return getInitialTrialAppRows();
}
